<html>
<body>
    <p>{{ $details['body'] }}</p>
</body>
</html>
