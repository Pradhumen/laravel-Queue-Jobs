<html>
<body>
    <p><?php echo e($details['body']); ?></p>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\eeeeeee\resources\views/emails/send-email.blade.php ENDPATH**/ ?>