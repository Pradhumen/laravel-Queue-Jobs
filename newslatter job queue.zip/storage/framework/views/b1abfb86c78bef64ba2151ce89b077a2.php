

<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Email Job Dashboard</h1>

    <?php if(session('success')): ?>
        <div class="alert alert-success">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <form action="<?php echo e(route('dashboard.startJobs')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <table class="table">
            <thead>
                <tr>
                    <th>Select</th>
                    <th>To</th>
                    <th>Subject</th>
                    <th>Body</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $jobs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td>
                            <input type="checkbox" name="job_ids[]" value="<?php echo e($job->id); ?>">
                        </td>
                        <td><?php echo e($job->to); ?></td>
                        <td><?php echo e($job->subject); ?></td>
                        <td><?php echo e($job->body); ?></td>
                        <td><?php echo e($job->status ?? 'Pending'); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <button type="submit" class="btn btn-primary">Start Selected Jobs</button>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\eeeeeee\resources\views/dashboard/index.blade.php ENDPATH**/ ?>