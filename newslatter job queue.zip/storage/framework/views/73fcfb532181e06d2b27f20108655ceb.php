<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $__env->yieldContent('title', 'Laravel Application'); ?></title>
    <!-- Add your CSS links here -->
    <link rel="stylesheet" href="<?php echo e(mix('css/app.css')); ?>">
    <!-- Add any additional CSS files if necessary -->
   
</head>
<body>
    <header>
        <nav>
            <!-- Navigation Links -->
            <ul>
                <li><a href="<?php echo e(url('/')); ?>">Home</a></li>
                <li><a href="<?php echo e(route('dashboard.index')); ?>">Dashboard</a></li>
                <li><a href="<?php echo e(route('newsletter.create')); ?>">Create Newsletter</a></li>
            </ul>
        </nav>
    </header>

    <main>
        <?php echo $__env->yieldContent('content'); ?>
    </main>

    <footer>
        <!-- Footer Content -->
        <p>&copy; <?php echo e(date('Y')); ?> Your Company. All rights reserved.</p>
    </footer>

    <!-- Add your JavaScript links here -->
 
    <!-- Add any additional JS files if necessary -->
    <?php echo $__env->yieldPushContent('scripts'); ?>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\eeeeeee\resources\views/layouts/app.blade.php ENDPATH**/ ?>